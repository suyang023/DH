#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dev Portal - 企业产品网站导航站
三级层级菜单架构 + 网址状态自动监控
"""

import json
import os
import uuid
import time
import threading
import secrets
import hashlib
import hmac
import urllib.request
import urllib.error
import re
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse, parse_qs
import http.server
import socketserver

PORT = 3022
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
SITES_FILE = os.path.join(DATA_DIR, "sites.json")
MENUS_FILE = os.path.join(DATA_DIR, "menus.json")
STATUSES_FILE = os.path.join(DATA_DIR, "statuses.json")
ADMIN_FILE = os.path.join(DATA_DIR, "admin.json")
PUBLIC_DIR = os.path.join(os.path.dirname(__file__), "public")

# 默认管理员账号（首次启动时若 admin.json 不存在则创建）
DEFAULT_ADMIN_USERNAME = "admin"
DEFAULT_ADMIN_PASSWORD = "Dh1111"
PBKDF2_ITERATIONS = 200000
TOKEN_TTL = 86400  # 24 小时

# 无需鉴权的路径白名单
AUTH_WHITELIST = (
    "/api/login",
    "/api/logout",
    "/api/auth/check",
    "/",
    "/index.html",
    "/manage.html",
    "/logo.png",
    "/favicon.ico",
)

# 首页只读 API（GET 方法无需登录，但 POST/PUT/DELETE 仍需登录）
PUBLIC_GET_APIS = (
    "/api/sites",
    "/api/menus",
    "/api/sites/statuses",
)

# 静态资源（CSS/JS 等）
AUTH_STATIC_PREFIXES = ("/css/", "/js/", "/public/")

# 状态监控配置
CHECK_TIMEOUT = 10  # 秒
CHECK_INTERVAL = 3600  # 1 小时
CHECK_START_HOUR = 7  # 早 7 点
CHECK_END_HOUR = 23  # 晚 11 点（不含）
MAX_WORKERS = 5  # 并发检测数


def load_json(path, default):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return default


def save_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_sites():
    return load_json(SITES_FILE, [])


def save_sites(sites):
    save_json(SITES_FILE, sites)


def load_menus():
    default = {
        "level1": [
            {"id": "l1-ibms", "name": "IBMS", "color": "#4F46E5", "sort_order": 1},
            {"id": "l1-energy", "name": "能源", "color": "#10B981", "sort_order": 2},
            {"id": "l1-tenant", "name": "租户", "color": "#F59E0B", "sort_order": 3},
        ],
        "level2": [
            {"id": "l2-zhidi", "parent_id": "l1-ibms", "name": "置地", "color": "#4F46E5", "sort_order": 1},
            {"id": "l2-jingdong", "parent_id": "l1-ibms", "name": "京东", "color": "#DC2626", "sort_order": 2},
            {"id": "l2-wanda", "parent_id": "l1-ibms", "name": "万达", "color": "#EF4444", "sort_order": 3},
            {"id": "l2-xincheng", "parent_id": "l1-ibms", "name": "新城", "color": "#F59E0B", "sort_order": 4},
        ],
        "level3_fixed": ["测试", "开发", "生产", "办公", "其他"],
    }
    return load_json(MENUS_FILE, default)


def save_menus(menus):
    save_json(MENUS_FILE, menus)


# ==================== 状态监控 ====================

def load_statuses():
    return load_json(STATUSES_FILE, {})


def save_statuses(statuses):
    save_json(STATUSES_FILE, statuses)


def check_single_url(url):
    """检查单个 URL，返回 (status_code, error_msg)"""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "DevPortal/1.0"})
        with urllib.request.urlopen(req, timeout=CHECK_TIMEOUT) as resp:
            return resp.status, ""
    except urllib.error.HTTPError as e:
        return e.code, str(e)
    except urllib.error.URLError as e:
        return 0, str(e.reason)
    except Exception as e:
        return 0, str(e)


def check_site(site):
    """检测单个站点，返回状态字典"""
    if not site.get("url"):
        return site["id"], {"status": "unknown", "last_check": now_str(), "code": 0, "error": "no url"}
    code, err = check_single_url(site["url"])
    status = "available" if code == 200 else "maintaining"
    return site["id"], {
        "status": status,
        "last_check": now_str(),
        "code": code,
        "error": err,
    }


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def check_all_sites():
    """检测所有站点，更新 statuses.json"""
    sites = load_sites()
    statuses = load_statuses()
    if not sites:
        return statuses

    print(f"[{now_str()}] 开始检测 {len(sites)} 个站点...")
    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = {pool.submit(check_site, s): s for s in sites}
        for fut in as_completed(futures):
            sid, result = fut.result()
            statuses[sid] = result
            site = futures[fut]
            print(f"  [{result['status']:12}] {site['name']} -> {result['code']}")
    save_statuses(statuses)
    print(f"[{now_str()}] 检测完成，结果已保存")
    return statuses


def in_check_window():
    """当前时间是否在检测窗口内 (7:00-23:00)"""
    h = datetime.now().hour
    return CHECK_START_HOUR <= h < CHECK_END_HOUR


def scheduler_loop():
    """后台调度循环"""
    # 启动时延迟 30 秒再开始第一次检测，让服务先稳定
    time.sleep(30)
    while True:
        try:
            if in_check_window():
                check_all_sites()
            else:
                print(f"[{now_str()}] 当前时间不在检测窗口内 ({CHECK_START_HOUR}:00-{CHECK_END_HOUR}:00)，跳过本轮")
        except Exception as e:
            print(f"[{now_str()}] 调度异常: {e}")
        time.sleep(CHECK_INTERVAL)


def start_scheduler():
    """启动后台调度线程"""
    t = threading.Thread(target=scheduler_loop, daemon=True)
    t.start()
    print(f"[{now_str()}] 后台状态监控线程已启动（窗口 {CHECK_START_HOUR}:00-{CHECK_END_HOUR}:00，每 {CHECK_INTERVAL//3600} 小时）")


def trigger_check_async(site):
    """异步触发单个站点检测"""
    def _run():
        statuses = load_statuses()
        sid, result = check_site(site)
        statuses[sid] = result
        save_statuses(statuses)
    threading.Thread(target=_run, daemon=True).start()


def trigger_check_all_async():
    """异步触发全量检测"""
    threading.Thread(target=check_all_sites, daemon=True).start()


# ==================== 鉴权模块 ====================

# 内存中的 token 字典：{token: {username, created_at}}
_token_store = {}
_token_lock = threading.Lock()


def hash_password(password, salt_hex, iterations=PBKDF2_ITERATIONS):
    """使用 PBKDF2-SHA256 哈希密码"""
    salt = bytes.fromhex(salt_hex)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return dk.hex()


def verify_password(password, salt_hex, expected_hash, iterations=PBKDF2_ITERATIONS):
    """常量时间比较，避免时序攻击"""
    actual = hash_password(password, salt_hex, iterations)
    return hmac.compare_digest(actual, expected_hash)


def init_admin_account():
    """首次启动时初始化默认管理员账号"""
    if os.path.exists(ADMIN_FILE):
        return
    salt = secrets.token_hex(16)
    password_hash = hash_password(DEFAULT_ADMIN_PASSWORD, salt)
    admin_data = {
        "username": DEFAULT_ADMIN_USERNAME,
        "password_hash": password_hash,
        "salt": salt,
        "iterations": PBKDF2_ITERATIONS,
    }
    save_json(ADMIN_FILE, admin_data)
    print(f"[{now_str()}] 已初始化默认管理员账号: {DEFAULT_ADMIN_USERNAME}")


def load_admin():
    return load_json(ADMIN_FILE, {})


def create_token(username):
    """生成新 token"""
    token = secrets.token_hex(32)
    with _token_lock:
        _token_store[token] = {
            "username": username,
            "created_at": time.time(),
        }
    return token


def validate_token(token):
    """校验 token，返回 username 或 None"""
    if not token:
        return
    with _token_lock:
        info = _token_store.get(token)
        if not info:
            return
        # 检查过期
        if time.time() - info["created_at"] > TOKEN_TTL:
            del _token_store[token]
            return
        return info["username"]


def revoke_token(token):
    with _token_lock:
        _token_store.pop(token, None)


def cleanup_expired_tokens():
    """定期清理过期 token"""
    while True:
        time.sleep(3600)
        with _token_lock:
            now = time.time()
            expired = [t for t, info in _token_store.items() if now - info["created_at"] > TOKEN_TTL]
            for t in expired:
                del _token_store[t]


# ==================== XSS 防护 ====================

# 危险模式（不区分大小写）
XSS_PATTERNS = [
    r"<script",
    r"</script",
    r"javascript:",
    r"vbscript:",
    r"on\w+\s*=",          # onerror=, onload=, onclick= 等
    r"<iframe",
    r"<object",
    r"<embed",
    r"<svg\s+[^>]*on",
    r"data:text/html",
    r"expression\s*\(",
    r"<meta\s+[^>]*http-equiv",
]
_XSS_RE = re.compile("|".join(XSS_PATTERNS), re.IGNORECASE)


def check_xss(value):
    """检测字符串是否含 XSS 危险内容，返回 (is_dangerous, matched_pattern)"""
    if not isinstance(value, str):
        return False, ""
    # 单字段长度限制
    if len(value) > 1000:
        return True, "字段过长"
    m = _XSS_RE.search(value)
    if m:
        return True, m.group(0)
    return False, ""


def validate_input(data):
    """递归校验 data 中所有字符串字段，返回第一个非法项的提示"""
    if isinstance(data, dict):
        for k, v in data.items():
            bad, why = check_xss(v)
            if bad:
                return f"字段 [{k}] 包含非法字符: {why}"
            inner = validate_input(v)
            if inner:
                return inner
    elif isinstance(data, list):
        for i, v in enumerate(data):
            bad, why = check_xss(v)
            if bad:
                return f"列表项 [{i}] 包含非法字符: {why}"
            inner = validate_input(v)
            if inner:
                return inner
    return None


# ==================== HTTP Handler ====================

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC_DIR, **kwargs)

    def _is_static_path(self, path):
        """判断是否为静态资源（CSS/JS 等）"""
        if path in AUTH_WHITELIST:
            return True
        for prefix in AUTH_STATIC_PREFIXES:
            if path.startswith(prefix):
                return True
        # favicon、其他静态文件
        if path.startswith("/logo") or path.endswith((".css", ".js", ".png", ".jpg", ".svg", ".ico", ".woff", ".woff2")):
            return True
        return False

    def _get_token_from_header(self):
        """从 Authorization 头提取 token"""
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            return auth[7:].strip()
        return None

    def _api_path(self):
        parsed = urlparse(self.path)
        return parsed.path, parse_qs(parsed.query)

    def _send_json(self, status, data):
        body = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length > 0 else b""
        if not raw:
            return {}
        for enc in ("utf-8", "gbk", "latin-1"):
            try:
                return json.loads(raw.decode(enc))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
        return json.loads(raw.decode("utf-8", errors="replace"))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def _check_auth(self, path):
        """统一鉴权检查，返回 True 表示通过，False 表示已拒绝"""
        if self._is_static_path(path):
            return True
        token = self._get_token_from_header()
        if validate_token(token):
            return True
        self._send_json(401, {"error": "unauthorized", "message": "请先登录"})
        return False

    def _check_xss_in_body(self, data):
        """对 body 中的字段做 XSS 检查，返回 True 表示通过"""
        err = validate_input(data)
        if err:
            self._send_json(400, {"error": "包含非法字符", "detail": err})
            return False
        return True

    def _merge_status(self, sites):
        statuses = load_statuses()
        for s in sites:
            st = statuses.get(s["id"], {"status": "unknown", "last_check": "", "code": 0, "error": ""})
            s["status"] = st.get("status", "unknown")
            s["last_check"] = st.get("last_check", "")
            s["status_code"] = st.get("code", 0)
            s["status_error"] = st.get("error", "")
        return sites

    # ==================== GET ====================
    def do_GET(self):
        path, qs = self._api_path()

        # GET 请求：登录/注销/公开 GET API 跳过鉴权，其他需要 token
        if path.startswith("/api/") and path not in AUTH_WHITELIST and path not in PUBLIC_GET_APIS:
            if not self._check_auth(path):
                return

        if path == "/api/sites":
            sites = self._merge_status(load_sites())
            self._send_json(200, sites)
        elif path == "/api/menus":
            self._send_json(200, load_menus())
        elif path == "/api/sites/statuses":
            self._send_json(200, load_statuses())
        elif path == "/api/auth/check":
            token = self._get_token_from_header()
            username = validate_token(token)
            if username:
                self._send_json(200, {"authenticated": True, "username": username})
            else:
                self._send_json(401, {"authenticated": False})
        else:
            super().do_GET()

# ==================== POST ====================
    def do_POST(self):
        path, qs = self._api_path()
        data = self._read_body()

        # 登录/注销 不需要鉴权
        if path == "/api/login":
            username = (data.get("username") or "").strip()
            password = data.get("password") or ""
            admin = load_admin()
            if not admin:
                self._send_json(500, {"error": "管理员账号未初始化"})
                return
            if not username or not password:
                self._send_json(400, {"error": "请输入账号和密码"})
                return
            # 常量时间比较 + 防爆破（基础版：连续失败延迟）
            if username != admin.get("username"):
                time.sleep(0.5)
                self._send_json(401, {"error": "账号或密码错误"})
                return
            salt = admin.get("salt")
            expected = admin.get("password_hash")
            iterations = admin.get("iterations", PBKDF2_ITERATIONS)
            if not verify_password(password, salt, expected, iterations):
                time.sleep(0.5)
                self._send_json(401, {"error": "账号或密码错误"})
                return
            token = create_token(username)
            self._send_json(200, {"token": token, "username": username, "expires_in": TOKEN_TTL})
            return

        if path == "/api/logout":
            token = self._get_token_from_header()
            if token:
                revoke_token(token)
            self._send_json(200, {"message": "已注销"})
            return

        # 其他 /api/* 需要鉴权
        if not self._check_auth(path):
            return

        # XSS 检测
        if path.startswith("/api/") and path not in ("/api/login", "/api/logout"):
            if not self._check_xss_in_body(data):
                return

        if path == "/api/sites":
            sites = load_sites()
            site = {
                "id": str(uuid.uuid4()),
                "name": data.get("name", ""),
                "url": data.get("url", "").rstrip("/"),
                "category": data.get("category", "其他"),
                "level1": data.get("level1", "IBMS"),
                "level2": data.get("level2", "置地"),
                "level3": data.get("level3", "测试"),
                "username": data.get("username", ""),
                "password": data.get("password", ""),
                "note": data.get("note", ""),
                "color": data.get("color", "#4F46E5"),
                "sort_order": data.get("sort_order", 0),
            }
            sites.append(site)
            save_sites(sites)
            trigger_check_async(site)
            self._send_json(201, site)

        elif path == "/api/menus/level1":
            menus = load_menus()
            item = {
                "id": data.get("id") or f"l1-{uuid.uuid4().hex[:8]}",
                "name": data.get("name", ""),
                "color": data.get("color", "#4F46E5"),
                "sort_order": data.get("sort_order", len(menus.get("level1", [])) + 1),
            }
            menus.setdefault("level1", []).append(item)
            save_menus(menus)
            self._send_json(201, item)

        elif path == "/api/menus/level2":
            menus = load_menus()
            item = {
                "id": data.get("id") or f"l2-{uuid.uuid4().hex[:8]}",
                "parent_id": data.get("parent_id", ""),
                "name": data.get("name", ""),
                "color": data.get("color", "#4F46E5"),
                "sort_order": data.get("sort_order", len(menus.get("level2", [])) + 1),
            }
            menus.setdefault("level2", []).append(item)
            save_menus(menus)
            self._send_json(201, item)

        elif path == "/api/sites/check-all":
            trigger_check_all_async()
            self._send_json(200, {"message": "检测任务已启动"})

        else:
            self._send_json(404, {"error": "not found"})

    # ==================== PUT ====================
    def do_PUT(self):
        path, qs = self._api_path()
        parts = path.strip("/").split("/")
        data = self._read_body()

        if not self._check_auth(path):
            return
        if not self._check_xss_in_body(data):
            return

        # /api/sites/{id}
        if len(parts) == 3 and parts[0] == "api" and parts[1] == "sites":
            sites = load_sites()
            for i, s in enumerate(sites):
                if s["id"] == parts[2]:
                    sites[i].update({
                        "name": data.get("name", s["name"]),
                        "url": data.get("url", s["url"]).rstrip("/"),
                        "category": data.get("category", s["category"]),
                        "level1": data.get("level1", s.get("level1", "IBMS")),
                        "level2": data.get("level2", s.get("level2", "置地")),
                        "level3": data.get("level3", s.get("level3", "测试")),
                        "username": data.get("username", s["username"]),
                        "password": data.get("password", s["password"]),
                        "note": data.get("note", s["note"]),
                        "color": data.get("color", s["color"]),
                        "sort_order": data.get("sort_order", s.get("sort_order", 0)),
                    })
                    save_sites(sites)
                    # 立即检测
                    trigger_check_async(sites[i])
                    self._send_json(200, sites[i])
                    return
            self._send_json(404, {"error": "site not found"})

        elif len(parts) == 4 and parts[0] == "api" and parts[1] == "menus":
            menus = load_menus()
            key = parts[2]
            target_id = parts[3]
            items = menus.get(key, [])
            for i, item in enumerate(items):
                if item["id"] == target_id:
                    items[i].update({
                        "name": data.get("name", item["name"]),
                        "color": data.get("color", item.get("color", "#4F46E5")),
                        "sort_order": data.get("sort_order", item.get("sort_order", 0)),
                    })
                    if key == "level2":
                        items[i]["parent_id"] = data.get("parent_id", item.get("parent_id"))
                    save_menus(menus)
                    self._send_json(200, items[i])
                    return
            self._send_json(404, {"error": "menu item not found"})

        else:
            self._send_json(404, {"error": "not found"})

    # ==================== DELETE ====================
    def do_DELETE(self):
        path, qs = self._api_path()
        parts = path.strip("/").split("/")

        if not self._check_auth(path):
            return

        if len(parts) == 3 and parts[0] == "api" and parts[1] == "sites":
            sites = load_sites()
            sites = [s for s in sites if s["id"] != parts[2]]
            save_sites(sites)
            # 同时清理状态
            statuses = load_statuses()
            statuses.pop(parts[2], None)
            save_statuses(statuses)
            self._send_json(200, {"deleted": parts[2]})

        elif len(parts) == 4 and parts[0] == "api" and parts[1] == "menus":
            menus = load_menus()
            key = parts[2]
            target_id = parts[3]
            if key in ("level1", "level2"):
                menus[key] = [x for x in menus.get(key, []) if x["id"] != target_id]
                if key == "level1":
                    menus["level2"] = [x for x in menus.get("level2", []) if x.get("parent_id") != target_id]
                save_menus(menus)
                self._send_json(200, {"deleted": target_id})
            else:
                self._send_json(404, {"error": "invalid key"})

        else:
            self._send_json(404, {"error": "not found"})

    def log_message(self, format, *args):
        print(f"[{self.log_date_time_string()}] {args[0]}")


if __name__ == "__main__":
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(PUBLIC_DIR, exist_ok=True)
    if not os.path.exists(MENUS_FILE):
        save_menus(load_menus())
    # 初始化默认管理员账号
    init_admin_account()
    # 启动后台调度线程
    start_scheduler()
    # 启动 token 清理线程
    threading.Thread(target=cleanup_expired_tokens, daemon=True).start()
    httpd = socketserver.TCPServer(("0.0.0.0", PORT), Handler)
    print(f"\n  Dev Portal 已启动")
    print(f"  访问地址: http://localhost:{PORT}")
    print(f"  管理后台默认账号: {DEFAULT_ADMIN_USERNAME}")
    print(f"  按 Ctrl+C 停止服务\n")
    httpd.serve_forever()