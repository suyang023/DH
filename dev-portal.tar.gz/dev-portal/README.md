# Dev Portal - 产品导航系统

## 快速开始

### 方式一：本地直接运行（Windows/Linux/Mac）

```bash
python server.py
```
访问地址：**http://localhost:3022**

### 方式二：Docker 部署（推荐用于 Ubuntu 服务器）

```bash
# 1. 进入项目目录
cd dev-portal

# 2. 构建并启动
docker compose up -d

# 3. 查看日志
docker compose logs -f dev-portal

# 4. 停止
docker compose down
```

访问地址：**http://服务器IP:3022**

## 目录结构

```
dev-portal/
├── server.py              # Python 后端服务（含状态监控、登录鉴权、XSS 防护）
├── start.bat / stop.bat   # Windows 本地启动/停止脚本
├── Dockerfile             # Docker 镜像构建文件
├── docker-compose.yml     # Docker Compose 一键部署
├── requirements.txt        # 依赖列表（零第三方依赖）
├── .dockerignore          # Docker 构建排除规则
├── logo.png               # 顶部 Logo 图片
├── data/                  # 数据目录（Docker 部署时挂载为卷）
│   ├── sites.json         # 站点数据
│   ├── menus.json         # 菜单数据
│   ├── statuses.json      # 站点状态数据（自动生成）
│   └── admin.json         # 管理员账号（自动生成）
├── backup/                # 历史备份
└── public/                # 静态资源
    ├── index.html         # 导航首页
    ├── manage.html        # 管理后台
    └── css/style.css      # 样式
```

## 默认账号

- **账号**：`admin`
- **密码**：`Dh1111`

⚠️ **首次登录后请修改默认密码**（可在 `data/admin.json` 中替换 `password_hash` 和 `salt` 字段）。

**生成新密码哈希**：
```python
python -c "
import secrets, hashlib
salt = secrets.token_hex(16)
password = input('新密码: ')
hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 200000).hex()
print(f'salt: {salt}')
print(f'password_hash: {hash}')
"
```

## 端口

默认 **3022**。如需修改，编辑 `server.py` 顶部的 `PORT` 变量。

## 功能

### 导航首页（http://localhost:3022）
- 左侧三级层级树（IBMS/能源/租户 → 二级项目 → 三级分类）
- 站点卡片显示账号密码（可一键复制）
- 顶部面包屑导航
- 三级分类筛选
- 关键词搜索
- 状态徽章（可访问/维护中，维护中卡片按钮置灰）
- **无需登录**即可使用

### 管理后台（http://localhost:3022/manage.html）
- **需登录**：默认 admin/Dh1111
- 站点管理（增删改查、排序）
- 菜单管理（一级固定、二级可自定义、三级固定）
- 站点状态实时显示
- 一键全量状态检测
- XSS 注入防护
- Token 鉴权（24 小时 TTL）

### 状态监控（自动后台运行）
- 每小时检测一次（窗口 7:00-23:00）
- 状态：可访问 / 维护中 / 检测中
- 新增/编辑站点后立即触发检测
- 数据存储：`data/statuses.json`

## 三级菜单架构

- **一级**（固定）：IBMS、能源、租户
- **二级**（默认4个，可自定义）：置地、京东、万达、新城 + 用户自定义
- **三级**（固定）：测试、开发、生产、办公、其他

## Ubuntu 服务器部署步骤

```bash
# 1. 安装 Docker 和 Docker Compose（Ubuntu）
sudo apt update
sudo apt install -y docker.io docker-compose-v2
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker $USER  # 可选，免 sudo

# 2. 复制项目到服务器
scp -r dev-portal/ user@server:/opt/

# 3. 启动服务
ssh user@server
cd /opt/dev-portal
docker compose up -d

# 4. 配置防火墙（如需要）
sudo ufw allow 3022/tcp

# 5. 访问
# http://服务器IP:3022
```

## 反向代理 + HTTPS（可选）

如果需要 HTTPS，可以启用 `docker-compose.yml` 中的 Nginx 配置（已注释）。

需要准备：
- 域名证书（如 Let's Encrypt）
- 修改 `nginx.conf` 配置

## 常见问题

### Q1: 忘记管理员密码怎么办？
A: 删除 `data/admin.json`，重启服务，会自动用默认账号 admin/Dh1111 重新创建。

### Q2: 状态检测为什么失败？
A: 检查目标网站 URL 是否正确，是否能从服务器访问。如果是内网地址，需要在能访问到内网的机器上部署。

### Q3: 端口被占用？
A: 修改 `server.py` 中的 `PORT` 变量，或在 `docker-compose.yml` 中改端口映射。

### Q4: 数据如何备份？
A: 整个 `data/` 目录就是数据，定期拷贝即可。Docker 部署时数据持久化在宿主机 `./data/`。

## 端口冲突

如提示端口占用，先运行 `stop.bat` 停止旧服务，再运行 `start.bat`（Windows本地）/ `docker compose down && docker compose up -d`（Docker）。