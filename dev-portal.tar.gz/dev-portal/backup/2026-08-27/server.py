#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dev Portal - 企业产品网站导航站
零外部依赖，仅用 Python 内建模块
运行方式: python server.py
访问地址: http://localhost:8080
"""

import json
import os
import uuid
import http.server
import socketserver
from urllib.parse import urlparse, parse_qs

PORT = 3021
DATA_FILE = os.path.join(os.path.dirname(__file__), "data", "sites.json")
PUBLIC_DIR = os.path.join(os.path.dirname(__file__), "public")


def load_sites():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []


def save_sites(sites):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(sites, f, ensure_ascii=False, indent=2)


class Handler(http.server.SimpleHTTPRequestHandler):
    # 静态文件根目录
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC_DIR, **kwargs)

    # ---------- API 路由 ----------

    def _api_path(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)
        return path, qs

    def _send_json(self, status, data):
        body = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self):
        length = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(length) if length > 0 else b""
        if not raw:
            return {}
        for enc in ("utf-8", "gbk", "latin-1"):
            try:
                return json.loads(raw.decode(enc))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
        # 兜底
        return json.loads(raw.decode("utf-8", errors="replace"))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path, qs = self._api_path()

        if path == "/api/sites":
            sites = load_sites()
            self._send_json(200, sites)
        else:
            # 交给父类处理静态文件
            super().do_GET()

    def do_POST(self):
        path, qs = self._api_path()

        if path == "/api/sites":
            data = self._read_body()
            sites = load_sites()
            site = {
                "id": str(uuid.uuid4()),
                "name": data.get("name", ""),
                "url": data.get("url", "").rstrip("/"),
                "category": data.get("category", "其他"),
                "username": data.get("username", ""),
                "password": data.get("password", ""),
                "note": data.get("note", ""),
                "color": data.get("color", "#4F46E5"),
                "sort_order": data.get("sort_order", 0),
            }
            sites.append(site)
            save_sites(sites)
            self._send_json(201, site)
        else:
            self._send_json(404, {"error": "not found"})

    def do_PUT(self):
        path, qs = self._api_path()

        # /api/sites/{id}
        parts = path.strip("/").split("/")
        if len(parts) == 3 and parts[0] == "api" and parts[1] == "sites":
            data = self._read_body()
            sites = load_sites()
            target_id = parts[2]
            for i, s in enumerate(sites):
                if s["id"] == target_id:
                    sites[i].update({
                        "name": data.get("name", s["name"]),
                        "url": data.get("url", s["url"]).rstrip("/"),
                        "category": data.get("category", s["category"]),
                        "username": data.get("username", s["username"]),
                        "password": data.get("password", s["password"]),
                        "note": data.get("note", s["note"]),
                        "color": data.get("color", s["color"]),
                        "sort_order": data.get("sort_order", s.get("sort_order", 0)),
                    })
                    save_sites(sites)
                    self._send_json(200, sites[i])
                    return
            self._send_json(404, {"error": "site not found"})
        else:
            self._send_json(404, {"error": "not found"})

    def do_DELETE(self):
        path, qs = self._api_path()

        parts = path.strip("/").split("/")
        if len(parts) == 3 and parts[0] == "api" and parts[1] == "sites":
            sites = load_sites()
            target_id = parts[2]
            sites = [s for s in sites if s["id"] != target_id]
            save_sites(sites)
            self._send_json(200, {"deleted": target_id})
        else:
            self._send_json(404, {"error": "not found"})

    def log_message(self, format, *args):
        """美化日志"""
        print(f"[{self.log_date_time_string()}] {args[0]}")


if __name__ == "__main__":
    os.makedirs(DATA_FILE if os.path.isdir(DATA_FILE) else os.path.dirname(DATA_FILE), exist_ok=True)
    os.makedirs(PUBLIC_DIR, exist_ok=True)
    httpd = socketserver.TCPServer(("0.0.0.0", PORT), Handler)
    print(f"\n  Dev Portal 已启动")
    print(f"  访问地址: http://localhost:{PORT}")
    print(f"  按 Ctrl+C 停止服务\n")
    httpd.serve_forever()
